print("Welcome to Virtual Pet World")
print("Select what type of pet you would like: ")
pet = int(input("(1) Dog\n(2) Cat\n(3) Bird\n(4) Hamster\n"))
if pet == 1:
    print("You selected a Dog")
if pet == 2:
    print("You selected a Cat")
if pet == 3:
    print("You selected a Bird")
if pet == 4:
    print("You selected a Hamster")
name = input("What do you want to name your pet? ")
print("You chose to name your pet", name)

EXIT = '6'
COMMANDS = ('1', '2', '3', '4', '5', '6')
MENU = """(1) Pet your pet
(2) Feed your pet
(3) Play with your pet
(4) Groom your pet
(5) Check your meters
(6) Quit the program"""


def main():
    while True:
        print(MENU)
        command = acceptCommand()
        runCommand(command)
        if command == EXIT:
            print("Come back soon!", name + " will be waiting for you.")
            break


def acceptCommand():
    """Inputs and returns a legitimate command number."""
    while True:
        command = input("Enter a number: ")
        if not command in COMMANDS:
            print("Error: command not recognized")
        else:
            return command


def runCommand(command):
    """Selects and runs a command."""
    Affection = 50
    Hunger = 50
    Clean = 50
    if command == '1':
        print("You chose to pet", name + ", their affection went up by 10")

    elif command == '2':
        print("You chose to feed", name + ", their hunger/thirst down by by 30")

    elif command == '3':
        print("You chose to play with", name + ", their affection went up by 20")

    elif command == '4':
        print("You chose to groom", name + ", their cleanliness meter went up by 15")

    elif command == '5':
        print("Affection:", Affection)
        print("Hunger:", Hunger)
        print("Cleanliness:", Clean)

if __name__ == "__main__":
    main()